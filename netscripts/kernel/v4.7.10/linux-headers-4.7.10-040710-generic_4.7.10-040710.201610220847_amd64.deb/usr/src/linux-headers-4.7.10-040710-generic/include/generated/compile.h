/* This file is auto generated, version 201610220847 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201610220847 SMP Sat Oct 22 12:50:14 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 6.2.0 20161005 (Ubuntu 6.2.0-5ubuntu12) "
